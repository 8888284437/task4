<h1 align="center">🌡️ Temperature Converter Application</h1>

## About
A temperature converter helps convert the temperature between Fahrenheit and Celsius scale. Temperature is measured using a thermometer. While Kelvin (K) is the SI unit of 
temperature, people generally use Centigrade or Celsius (°C) and Fahrenheit (°F) to measure temperature.

## Features
In this application, you can convert the temperature from Celsius to Fahrenheit and vice-versa.

## Made with
|HTML|CSS|Javascript|
|---|---|---|

## Link
https://thenewc0der-24.github.io/Temperature__Converter-Application/

---
<h3 align="center">Hope this application helpful to you !!</h3>
